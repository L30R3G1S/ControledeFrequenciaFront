document.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");

  if (!token) {
    window.location.href = "index.html";
    return;
  }
});

function logout() {
  localStorage.removeItem("token");
  window.location.href = "index.html";
}


const filtroInput = document.getElementById("filtroCPF");


 
function carregarTabelaDoBanco() {
  fetch('https://controledefrequencia.onrender.com/relatorio')
    .then(res => res.json())
    .then(dados => {
      tabelaCorpo.innerHTML = "";

      dados.forEach(item => {
        const linha = document.createElement("tr");
        const alerta = item["Dias Trabalhados"] >= 6 ? ' style="background-color: #ffdddd; font-weight: bold;"' : '';

        linha.innerHTML = `
          <td>${item.Nome}</td>
          <td>${item.CPF}</td>
          <td${alerta}>${item["Dias Trabalhados"]}</td>
        `;
        tabelaCorpo.appendChild(linha);
      });

      const agora = new Date();
      ultimaImportacao.textContent = `Última importação: ${agora.toLocaleString('pt-BR')}`;
    });
}

filtroInput.addEventListener("keyup", () => {
  const cpfFiltro = filtroInput.value.toLowerCase();
  const linhas = document.querySelectorAll("#tabela-corpo tr");
  linhas.forEach(linha => {
    const cpf = linha.children[1].textContent.toLowerCase();
    linha.style.display = cpf.includes(cpfFiltro) ? "" : "none";
  });
});

window.addEventListener("DOMContentLoaded", carregarTabelaDoBanco);


