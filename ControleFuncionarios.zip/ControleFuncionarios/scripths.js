const tabelaCorpo = document.getElementById("tabela-corpo");
const uploadBox = document.getElementById("uploadBox");
const fileInput = document.getElementById("fileInput");
const statusImportacao = document.getElementById("statusImportacao");
const ultimaImportacao = document.getElementById("ultimaImportacao");
const enviarBtn = document.getElementById("enviarArquivoBtn");

let arquivoSelecionado = null;
let mensagemTimeout = null;



function logout() {
  localStorage.removeItem("token");
  window.location.href = "index.html";
}

// verificar upload lento ou parou de funcionar

document.addEventListener("DOMContentLoaded", carregarHistorico);
uploadBox.addEventListener("click", () => fileInput.click());

uploadBox.addEventListener("dragover", (e) => {
  e.preventDefault();
  uploadBox.classList.add("dragover");
});

uploadBox.addEventListener("dragleave", () =>
  uploadBox.classList.remove("dragover")
);

uploadBox.addEventListener("drop", (e) => {
  e.preventDefault();
  uploadBox.classList.remove("dragover");
  if (e.dataTransfer.files.length) {
    arquivoSelecionado = e.dataTransfer.files[0];
    statusImportacao.textContent = `Arquivo pronto para envio: ${arquivoSelecionado.name}`;
    statusImportacao.style.color = "#333";
  }
});

fileInput.addEventListener("change", (e) => {
  clearTimeout(mensagemTimeout);
  if (e.target.files.length) {
    arquivoSelecionado = e.target.files[0];
    statusImportacao.textContent = `Arquivo pronto para envio: ${arquivoSelecionado.name}`;
    statusImportacao.style.color = "#333";
  }
});

enviarBtn.addEventListener("click", () => {
  if (!arquivoSelecionado) {
    alert("Por favor, selecione um arquivo antes de enviar.");
    return;
  }

  clearTimeout(mensagemTimeout);
  statusImportacao.textContent = "Enviando arquivo...";
  statusImportacao.style.color = "#333";
  enviarBtn.disabled = true;

  function processarArquivo(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = function (e) {
        try {
          console.log("🔄 Lendo arquivo...");

          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const json = XLSX.utils.sheet_to_json(sheet, {
            header: ["cpf", "name", "date", "hour"],
            range: 1,
            raw: true,
          });

          const payload = {
            archiveName: file.name,
            registry: json,
          };

          fetch("https://controledefrequencia.onrender.com/upload", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
            body: JSON.stringify(payload),
          })
            .then((response) => {
              console.log("📡 Resposta do servidor:", response);
              if (!response.ok) throw new Error("Erro no envio dos dados");
              return response.json();
            })
            .then(() => resolve())
            .catch((err) => {
              console.error("❌ Erro no fetch:", err);
              reject(err);
            });
        } catch (error) {
          console.error("❌ Erro ao ler ou converter planilha:", error);
          reject(error);
        }
      };

      reader.onerror = () => reject(reader.error);
      reader.readAsArrayBuffer(file);
    });
  }

  processarArquivo(arquivoSelecionado)
    .then(() => {
      statusImportacao.innerHTML = `✅ Arquivo <strong>${arquivoSelecionado.name}</strong> enviado com sucesso!`;
      statusImportacao.style.color = "green";
      fileInput.value = "";
      arquivoSelecionado = null;
      carregarHistorico();

      mensagemTimeout = setTimeout(() => {
        statusImportacao.textContent = "";
      }, 7000);
    })
    .catch((error) => {
      console.error(error);
      statusImportacao.textContent = "Erro ao importar dados.";
      statusImportacao.style.color = "red";
    })
    .finally(() => {
      enviarBtn.disabled = false;
    });
});

async function carregarHistorico() {
  const token = localStorage.getItem("token");
  const corpoTabela = document.getElementById("corpo-historico");
  const tabela = document.getElementById("tabela-historico");
  const mensagemVazia = document.getElementById("sem-planilhas");

  corpoTabela.innerHTML = "<tr><td colspan='4'>🔄 Carregando...</td></tr>";

  try {
    const res = await fetch(
      "https://controledefrequencia.onrender.com/upload",
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!res.ok) throw new Error("Erro ao buscar histórico");

    const planilhas = await res.json();
    planilhas.sort((a, b) => new Date(b.uploadDate) - new Date(a.uploadDate));
    if (!Array.isArray(planilhas) || planilhas.length === 0) {
      corpoTabela.innerHTML = "";
      mensagemVazia.style.display = "block";
      tabela.style.display = "none";
      return;
    }

    mensagemVazia.style.display = "none";
    tabela.style.display = "table";

    corpoTabela.innerHTML = ""; // Limpa conteúdo antigo

    function formatarDataBrasileira(utcDateStr) {
      const data = new Date(utcDateStr);
      data.setHours(data.getHours() - 3); // Ajuste UTC-3
      return data.toLocaleString("pt-BR");
    }
    console.log("Resposta do backend:", planilhas);
    planilhas.forEach((p) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${p.archiveName}</td>
        <td>${p.responsible}</td>
        <td>${formatarDataBrasileira(p.uploadDate)}</td>
        <td>
          <button class="btn btn-excluir" onclick="excluirPlanilha(${
            p.id
          }, this)">Excluir</button>
        </td>
      `;
      corpoTabela.appendChild(tr);
    });
  } catch (err) {
    console.error("Erro ao carregar histórico:", err);
    corpoTabela.innerHTML =
      "<tr><td colspan='4'>❌ Erro ao carregar dados.</td></tr>";
  }
}


